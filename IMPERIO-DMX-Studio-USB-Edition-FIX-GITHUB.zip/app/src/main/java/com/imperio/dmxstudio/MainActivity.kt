package com.imperio.dmxstudio

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.delay

private val Bg = Color(0xFF101318)
private val Panel = Color(0xFF1C222B)
private val Accent = Color(0xFF00C8A0)

class MainActivity : ComponentActivity() {
    private lateinit var engine: DmxEngine
    private val usbPermissionAction = "com.imperio.dmxstudio.USB_PERMISSION"

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == usbPermissionAction) {
                val device = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, android.hardware.usb.UsbDevice::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                if (granted && device != null) engine.connect { usbStatus = it }
                else usbStatus = "Permiso USB denegado"
            }
        }
    }

    private var usbStatus by mutableStateOf("USB desconectado")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = DmxEngine(this)
        val filter = IntentFilter(usbPermissionAction)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(usbReceiver, filter)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                ImperioApp(engine, usbStatus, { requestUsbPermission() }, { usbStatus = it })
            }
        }
    }

    private fun requestUsbPermission() {
        val manager = getSystemService(Context.USB_SERVICE) as UsbManager
        val driver = com.hoho.android.usbserial.driver.UsbSerialProber.getDefaultProber()
            .findAllDrivers(manager).firstOrNull()
        if (driver == null) {
            usbStatus = "Conectá una interfaz USB-DMX compatible mediante OTG"
            return
        }
        if (manager.hasPermission(driver.device)) {
            engine.connect { usbStatus = it }
        } else {
            val intent = PendingIntent.getBroadcast(
                this, 0, Intent(usbPermissionAction).setPackage(packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            manager.requestPermission(driver.device, intent)
            usbStatus = "Esperando autorización de Android…"
        }
    }

    override fun onDestroy() {
        engine.disconnect()
        try { unregisterReceiver(usbReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
private fun ImperioApp(
    engine: DmxEngine,
    usbStatus: String,
    onConnect: () -> Unit,
    setStatus: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedFixture by remember { mutableIntStateOf(1) }
    var page by remember { mutableIntStateOf(0) }
    var selectedTab by remember { mutableStateOf("CONTROL") }
    var channelValues by remember { mutableStateOf(List(192) { 0 }) }
    var scenes by remember { mutableStateOf(loadScenes(context)) }
    var activeScene by remember { mutableIntStateOf(-1) }
    var blackout by remember { mutableStateOf(false) }
    var auto by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(50f) }
    var fixtureAddresses by remember { mutableStateOf((0..11).map { it * 16 + 1 }) }

    // Chase real: recorre las ocho escenas guardadas mientras AUTO está activo.
    LaunchedEffect(auto, speed, scenes, blackout) {
        while (auto) {
            for (sceneIndex in 0..7) {
                if (!auto) break
                val scene = scenes[sceneIndex]
                if (scene.size == 192) {
                    channelValues = scene
                    scene.forEachIndexed { i, v -> engine.setChannel(i + 1, if (blackout) 0 else v) }
                    engine.sendFrame()
                    activeScene = sceneIndex
                }
                delay((2100f - speed * 18f).toLong().coerceAtLeast(300L))
            }
        }
    }

    fun updateChannel(slot: Int, dmxChannel: Int, value: Int) {
        val updated = channelValues.toMutableList()
        updated[slot - 1] = value
        channelValues = updated
        engine.setChannel(dmxChannel, if (blackout) 0 else value)
        engine.sendFrame()
    }
    fun saveScene(index: Int) {
        val copy = scenes.toMutableList()
        copy[index] = channelValues
        scenes = copy
        saveScenes(context, scenes)
        activeScene = index
        setStatus("Escena ${index + 1} guardada")
    }
    fun recallScene(index: Int) {
        if (scenes[index].isNotEmpty()) {
            channelValues = scenes[index]
            channelValues.forEachIndexed { i, v -> engine.setChannel(i + 1, if (blackout) 0 else v) }
            engine.sendFrame()
            activeScene = index
            setStatus("Escena ${index + 1} cargada")
        } else setStatus("La escena ${index + 1} está vacía")
    }

    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("IMPERIO", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineMedium)
                Text("DMX STUDIO  •  USB EDITION", color = Accent, style = MaterialTheme.typography.labelSmall)
            }
            Button(onClick = onConnect) { Text("USB DMX") }
        }
        Spacer(Modifier.height(8.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text(usbStatus, color = if (usbStatus.contains("conectado", true)) Accent else Color.LightGray)
                Text("Universo DMX: 512 canales  •  Motor: 192 canales", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("CONTROL", "FIXTURES", "ESCENAS", "CHASE").forEach { tab ->
                FilterChip(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab) })
            }
        }
        Spacer(Modifier.height(12.dp))

        when (selectedTab) {
            "CONTROL" -> {
                Text("SALIDA DMX · CANALES ${page * 8 + 1}–${page * 8 + 8}", color = Accent, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("PAGE A" to 0, "PAGE B" to 1).forEach { (label, value) ->
                        OutlinedButton(onClick = { page = value }) { Text(label) }
                    }
                }
                for (row in 0..1) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (col in 0..3) {
                            val slot = (selectedFixture - 1) * 16 + page * 8 + row * 4 + col + 1
                            val channel = fixtureAddresses[selectedFixture - 1] + page * 8 + row * 4 + col
                            Column(Modifier.weight(1f).background(Panel).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("CH $channel", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                                var value by remember(slot) { mutableFloatStateOf(channelValues[slot - 1].toFloat()) }
                                Slider(
                                    value = value, onValueChange = {
                                        value = it
                                        updateChannel(slot, channel, it.toInt())
                                    },
                                    valueRange = 0f..255f,
                                    modifier = Modifier.height(190.dp).width(42.dp)
                                )
                                Text(value.toInt().toString(), color = Accent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Text("Fixtures", color = Accent, fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (1..12).forEach { id ->
                        FilterChip(selected = selectedFixture == id, onClick = { selectedFixture = id }, label = { Text("$id") })
                    }
                }
                Text("Fixture seleccionado: $selectedFixture", color = Color.LightGray)
            }
            "FIXTURES" -> {
                Text("CONFIGURACIÓN DE LUMINARIAS", color = Accent, fontWeight = FontWeight.Bold)
                Text("12 posiciones de fixture. Asigná la dirección inicial según el modo DMX de cada luminaria.", color = Color.LightGray)
                (1..12).forEach { id ->
                    val address = fixtureAddresses[id - 1]
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("FIXTURE $id", Modifier.weight(1f))
                        Text("ADDR", color = Color.Gray)
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(
                            value = address.toString(),
                            onValueChange = { text ->
                                text.toIntOrNull()?.let { n ->
                                    if (n in 1..497) fixtureAddresses = fixtureAddresses.toMutableList().also { it[id - 1] = n }
                                }
                            },
                            modifier = Modifier.width(100.dp), singleLine = true
                        )
                    }
                }
                Text("Cada fixture usa 16 canales consecutivos por defecto. En CONTROL, PAGE A/B maneja los primeros 8 y los siguientes 8 canales de la luminaria seleccionada.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
            "ESCENAS" -> {
                Text("MEMORIAS DE ESCENA", color = Accent, fontWeight = FontWeight.Bold)
                Text("Tocá GUARDAR para almacenar el estado actual o CARGAR para recuperarlo.", color = Color.LightGray)
                (0..7).forEach { index ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("SCENE ${index + 1}", Modifier.weight(1f))
                        OutlinedButton(onClick = { saveScene(index) }) { Text("GUARDAR") }
                        Spacer(Modifier.width(6.dp))
                        Button(onClick = { recallScene(index) }) { Text("CARGAR") }
                    }
                }
            }
            else -> {
                Text("CHASE · SECUENCIAS", color = Accent, fontWeight = FontWeight.Bold)
                Text("Seleccioná una velocidad y activá AUTO para recorrer automáticamente las escenas guardadas.", color = Color.LightGray)
                Text("SPEED ${speed.toInt()}%", color = Color.White)
                Slider(value = speed, onValueChange = { speed = it }, valueRange = 1f..100f)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = auto, onCheckedChange = { auto = it })
                    Text(if (auto) "AUTO ACTIVADO" else "AUTO DESACTIVADO")
                }
                Text("El CHASE recorre las escenas 1 a 8 que tengan datos guardados. La velocidad regula el intervalo entre pasos.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    blackout = !blackout
                    for (ch in 1..192) engine.setChannel(ch, if (blackout) 0 else channelValues[ch - 1])
                    engine.sendFrame()
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = if (blackout) Color.Red else Color(0xFF8A2020))
            ) { Text(if (blackout) "REACTIVAR" else "BLACKOUT") }
            OutlinedButton(onClick = {
                for (ch in 1..192) engine.setChannel(ch, channelValues[ch - 1])
                engine.sendFrame()
                setStatus("Trama DMX enviada")
            }, modifier = Modifier.weight(1f)) { Text("ENVIAR DMX") }
        }
        Spacer(Modifier.height(18.dp))
        Text("IMPERIO DMX Studio · versión 1.0.0", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
    }
}

private fun loadScenes(context: Context): List<List<Int>> {
    val raw = context.getSharedPreferences("imperio_dmx", Context.MODE_PRIVATE).getString("scenes", null)
        ?: return List(8) { emptyList() }
    return try {
        val array = JSONArray(raw)
        List(8) { i ->
            val item = array.optJSONArray(i)
            if (item == null) emptyList() else List(item.length()) { j -> item.optInt(j) }
        }
    } catch (_: Exception) { List(8) { emptyList() } }
}

private fun saveScenes(context: Context, scenes: List<List<Int>>) {
    val outer = JSONArray()
    scenes.forEach { scene ->
        val inner = JSONArray()
        scene.forEach { inner.put(it) }
        outer.put(inner)
    }
    context.getSharedPreferences("imperio_dmx", Context.MODE_PRIVATE)
        .edit().putString("scenes", outer.toString()).apply()
}
