package com.imperio.dmxstudio

import android.content.Context
import android.hardware.usb.UsbManager
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.util.concurrent.Executors

/**
 * USB DMX output for ENTTEC DMX USB Pro-compatible serial interfaces.
 * This is not a universal driver for every USB-DMX cable.
 */
class DmxEngine(private val context: Context) {
    val values = IntArray(513) // slot 0 is DMX start code; slots 1..512 are channels
    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null
    private val executor = Executors.newSingleThreadExecutor()

    @Volatile var connected: Boolean = false
        private set

    fun findUsbDevice(): String {
        val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(manager)
        return if (drivers.isEmpty()) "No se detectó una interfaz USB serial compatible"
        else "Interfaz detectada: ${drivers.first().device.deviceName}"
    }

    fun connect(onResult: (String) -> Unit) {
        try {
            val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
            val driver = UsbSerialProber.getDefaultProber().findAllDrivers(manager).firstOrNull()
                ?: run { onResult("No se encontró interfaz USB serial"); return }
            if (!manager.hasPermission(driver.device)) {
                onResult("Permiso USB pendiente. Desconectá y reconectá si Android no muestra el permiso.")
                return
            }
            val connection = manager.openDevice(driver.device)
                ?: run { onResult("Android no pudo abrir el dispositivo USB"); return }
            val selected = driver.ports.firstOrNull()
                ?: run { connection.close(); onResult("La interfaz no ofrece puertos"); return }

            selected.open(connection)
            // ENTTEC DMX USB Pro uses a serial framing protocol at 57600 baud.
            selected.setParameters(57600, 8, UsbSerialPort.STOPBITS_2, UsbSerialPort.PARITY_NONE)
            port = selected
            connected = true
            sendFrame()
            onResult("USB conectado. Protocolo ENTTEC USB Pro.")
        } catch (e: Exception) {
            connected = false
            onResult("Error USB: ${e.message ?: "desconocido"}")
        }
    }

    @Synchronized fun setChannel(channel: Int, value: Int) {
        if (channel in 1..512) values[channel] = value.coerceIn(0, 255)
    }

    @Synchronized fun sendFrame() {
        val p = port ?: return
        try {
            // ENTTEC DMX USB Pro: 0x7E, label 6, length LSB, length MSB, start code + 512 slots, 0xE7
            val payloadLength = 513
            val packet = ByteArray(payloadLength + 5)
            packet[0] = 0x7E
            packet[1] = 6
            packet[2] = (payloadLength and 0xFF).toByte()
            packet[3] = ((payloadLength shr 8) and 0xFF).toByte()
            for (i in 0 until payloadLength) packet[4 + i] = values[i].toByte()
            packet[packet.lastIndex] = 0xE7.toByte()
            p.write(packet, 100)
        } catch (_: Exception) {
            connected = false
        }
    }

    fun disconnect() {
        try { ioManager?.stop() } catch (_: Exception) {}
        ioManager = null
        try { port?.close() } catch (_: Exception) {}
        port = null
        connected = false
    }
}
