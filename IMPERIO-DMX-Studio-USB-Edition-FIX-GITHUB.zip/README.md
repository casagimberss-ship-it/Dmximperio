# IMPERIO DMX Studio — USB Edition

Aplicación Android nativa para control DMX por USB OTG. Primera base funcional de desarrollo.

## Requisitos
- Android 6.0 o superior con USB Host.
- Cable/adaptador USB OTG.
- Interfaz USB serial compatible con `usb-serial-for-android`.
- Interfaz DMX compatible con el protocolo ENTTEC DMX USB Pro.

## Compilar en GitHub
1. Crear un repositorio GitHub llamado `IMPERIO-DMX-Studio`.
2. Subir el contenido de este ZIP a la raíz del repositorio.
3. Abrir **Actions** y ejecutar **Build IMPERIO DMX Studio APK**.
4. Descargar el artefacto `IMPERIO-DMX-Studio-debug`.
5. Dentro estará `app-debug.apk`.

También se compila automáticamente al hacer push a `main` o `master`.

## Conexión USB
1. Conectar el adaptador DMX al teléfono mediante OTG.
2. Abrir la aplicación y pulsar USB DMX.
3. Aceptar el permiso USB de Android.
4. Conectar la salida DMX del adaptador a la primera luminaria.

## Compatibilidad importante
No todos los cables USB-DMX usan el mismo chipset ni protocolo. Esta versión usa el prober serial estándar de `usb-serial-for-android` y envía tramas de salida ENTTEC DMX USB Pro (label 6). Para validar compatibilidad real hace falta conocer la marca/modelo o chipset del adaptador. Adaptadores DMX USB genéricos, Open DMX, DMXKing y otros protocolos pueden requerir controladores diferentes.

## Estado de funciones
- Implementado en esta base: interfaz Compose, 192 canales de control agrupados en 12 fixtures de 16 canales, PAGE A/B, direcciones iniciales editables, memoria local de 8 escenas, carga/guardado, CHASE básico temporizado, blackout y envío de tramas ENTTEC Pro.
- Pendiente de completar: perfiles de luminarias por fabricante, sincronización por micrófono, persistencia de direcciones, prueba de hardware y compatibilidad con otros adaptadores.
- El control de 192 canales en pantalla no limita la trama USB: el universo DMX transmitido contiene 512 slots.

## Notas técnicas
La aplicación no puede transmitir DMX por el puerto USB-C directamente sin una interfaz USB-DMX compatible. El teléfono debe soportar USB Host/OTG.
